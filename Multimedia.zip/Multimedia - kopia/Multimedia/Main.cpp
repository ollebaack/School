#include <iostream>
#include <iomanip>
#include <conio.h>
#include <cctype>
#include "Multimedia.h"
using namespace std;
#include <vector>
#include <iostream>
#include <fstream>
#include <algorithm>
#include "Register.h"


int main() {

	int x = 1;
	Register n1;

	Multimedia v1;
	

	while (x != 7)
	{
		cout << "Choose between \n 1. Add to file \n 2. Search in file \n 3. Delete a file \n 4. Print out all songs \n 5. Write to file \n 6. Read from file \n 7. Quit" << endl;
		cout << "Val: ";
		cin >> x;
		cin.get();
		cout << endl;

		switch (x)
		{
		case 1:
			cout << "Add to file" << endl;
			n1.add();
			break;

		case 2:
			cout << "Search in file" << endl;
			n1.search();
			break;

		case 3:
			cout << "Delete a file" << endl;
			n1.delete_multi();
			break;
		case 4:
			cout << "List of all songs:" << endl;
			n1.List();
			break;
		case 5:
			n1.WriteFile();
			break;
		case 6:
			n1.ReadFromFile();
			break;
		case 7:
			break;
		default:
			break;
		}
	}

	system("pause");

	return 0;

}
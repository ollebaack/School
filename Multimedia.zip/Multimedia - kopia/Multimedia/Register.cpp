#include <iostream>
#include <iomanip>
#include <conio.h>
#include <cctype>
#include "Multimedia.h"
#include "Register.h"
using namespace std;
#include <vector>
#include <iostream>
#include <algorithm>
#include <fstream>


void Register::add()
{
	Multimedia obj1;
	cout << "Type songtitle and year to it: ";
	cin >> obj1;
	if (obj1.ar >= 0)
	{
		v.push_back(obj1);
		cout << "Your song was successfully added" << endl << endl;
	}
	else
		cout << "ERROR! There is no song made that year..." << endl << endl;
}



void Register::delete_multi()
{
	string s;
	cout << "Type songname: ";
	cin >> s;
	if (v.size() == 0)
		cout << "There isn't a song named that." << endl << endl;
	for (unsigned int i = 0; i < v.size(); i++)
	{
		if (v[i].namn == s)
		{
			v.erase(v.begin() + i);
			cout << "You successfully deleted the file!" << endl << endl;
		}
		else
			cout << "There isn't a song named that." << endl;
	}

}

void Register::search()
{
	string s;
	cout << "Type songname: ";
	cin >> s;
	if (v.size() == 0)
		cout << "There isn't a song named that." << endl << endl;
	for (unsigned int i = 0; i < v.size(); i++)
	{
		if (v[i].namn == s)
		{
			cout << "Song: " << v[i].namn << " " << endl;
			cout << "Year: " << v[i].ar << endl << endl;
		}
		else
			cout << "There isn't a song named that." << endl << endl;
	}
}

void Register::List()
{
	for (unsigned int i = 0; i < v.size(); i++)
	{
		cout << v[i] << endl;
	}
}

Register::Register()
{
}
ostream & operator<<(ostream & stream, Multimedia & multi)
{
	stream << multi.namn << " " << multi.ar;
	return stream;
}

istream& operator >> (istream & stream, Multimedia & multi)
{

	stream >> multi.namn;
	stream >> multi.ar;
	return stream;
}

void Register::WriteFile()
{
	ofstream myfile;
	myfile.open("SongList.txt");
	myfile << "Song List:" << endl << endl;

	for (unsigned int i = 0; i < v.size(); i++)
	{

		myfile /*<< i+1 << ". "  */<< v[i] << endl;
	}
	myfile.close();
}

void Register::ReadFromFile()
{
	v.clear();
	string strRow;
	ifstream fin("SongList.txt");

	getline(fin, strRow);
	getline(fin, strRow);

	while (getline(fin, strRow))
	{
		istringstream iss(strRow);
		string str;
		Multimedia m;
		iss >> m;
		v.push_back(m);

	}

	fin.close();

}

Register::~Register()
{

}
